#include <QCoreApplication>
#include "./Logic/filelogic.h"
#include "./Global/ref.h"
#include "./Global/datastructure.h"
#include<QtDebug>
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QFile qfile(_T("111.txt"));
    qfile.open(QIODevice::WriteOnly);
    QDataStream out(&qfile);
    VARCHAR var="123123";
     VARCHAR var1="12";
    out<<var<<var1;
    qDebug()<<var;

    qfile.close();
    return a.exec();
}
