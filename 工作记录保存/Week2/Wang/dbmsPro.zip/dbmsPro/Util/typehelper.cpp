#include "typehelper.h"

TypeHelper::TypeHelper()
{

}
