#ifndef TYPEHELPER_H
#define TYPEHELPER_H


class TypeHelper
{
public:
    TypeHelper();
};

#endif // TYPEHELPER_H