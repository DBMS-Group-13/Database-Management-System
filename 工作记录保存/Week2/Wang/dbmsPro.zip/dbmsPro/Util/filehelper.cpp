#include "filehelper.h"
#include "appexception.h"
#include<QFile>
#include<QDir>
#include<excpt.h>
// 创建文件,QString 为文件相对路径
bool FileHelper::CreateFile(const QString strFileName)
{
   /* try
    {
        // 创建文件夹
        for (int i = 0; i < strFileName.length(); i++)
        {
            if ( ('\\' == strFileName.at(i)
                || '/' == strFileName.at(i))
                && 2 != i
                )
            {
                QDir dir(strFileName.left(i));
                if(!dir.exists())
                {
                  if(!dir.mkdir(strFileName.left(i)))
                      return false;
                }
            }
        }

        // 创建文件
        QFile file(strFileName);
        if (!file.open(QIODevice::WriteOnly))
        {
            return false;
        }
        file.close();

        return true;
    }
    catch (QString e)
    {
        printf(e.toStdString().data());
        throw new AppException();
    }*/

    return false;
}
// 检测文件是否存在，QString为文件相对路径
bool FileHelper::IsValidFile(const QString strPath){
    return false;
}

