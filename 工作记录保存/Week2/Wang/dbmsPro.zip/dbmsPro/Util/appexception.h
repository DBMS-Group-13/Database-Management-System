#ifndef APPEXCEPTION_H
#define APPEXCEPTION_H

#include <QException>

class AppException
{
public:
    AppException();
};

#endif // APPEXCEPTION_H
