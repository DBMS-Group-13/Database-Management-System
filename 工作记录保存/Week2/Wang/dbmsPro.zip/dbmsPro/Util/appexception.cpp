#include "appexception.h"

AppException::AppException()
{

}
