#include "recordentity.h"

RecordEntity::RecordEntity()
{

}
