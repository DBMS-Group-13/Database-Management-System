#include "tableentity.h"

TableEntity::TableEntity()
{

}
