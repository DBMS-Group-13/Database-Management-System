#include "fieldentity.h"

FieldEntity::FieldEntity()
{

}
