#ifndef FIELDENTITY_H
#define FIELDENTITY_H
#include "./Global/ref.h"

class FieldEntity
{
public:
    FieldEntity();
};
typedef QHash<int, FieldEntity*> FIELDARRAY;
#endif // FIELDENTITY_H
