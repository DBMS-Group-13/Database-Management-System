#ifndef RECORDENTITY_H
#define RECORDENTITY_H
#include "./Global/ref.h"
class RecordEntity
{
public:
    RecordEntity();
};
typedef QHash<int, RecordEntity*> RECORDARR;
#endif // RECORDENTITY_H
