#ifndef TABLEDATAOPS_H
#define TABLEDATAOPS_H
#include ".\Entity\TableEntity.h"
#include ".\Entity\FieldEntity.h"
#include<QString>
class TableDataOps
{
public:
    TableDataOps();
    // Create table and save table information
    bool Create(const QString strFilePath, TableEntity &te);
    // Add a table field
    bool AddField(const QString strFilePath, FieldEntity &fe);
    // Get table information
    int GetTables(const QString strFilepath, TABLEARR &arr);
    // Get field information
    bool GetFields(const QString strFilepath, TableEntity &te);
    // Alert table
    bool AlterTable(const QString strFilePath, TableEntity &te);
};

#endif // TABLEDATAOPS_H
