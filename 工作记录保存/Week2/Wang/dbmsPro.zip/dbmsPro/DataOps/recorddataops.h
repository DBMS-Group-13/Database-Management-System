#ifndef RECORDDATAOPS_H
#define RECORDDATAOPS_H
#include ".\Entity\tableentity.h"
#include ".\Entity\recordentity.h"
#include <QFile>
class RecordDataOps
{
public:
    RecordDataOps();
    // Create new rows in a table
    bool Insert(TableEntity &te, RecordEntity &re);
    // Retrieve all records from a specified table
    int SelectAll(TableEntity &te, RECORDARR &data);

private:
    // Save record
    bool Write(QFile &file, TableEntity &te, RecordEntity &re);
    // Get record
    bool Read(QFile &file, TableEntity &te, RecordEntity &re);
};

#endif // RECORDDATAOPS_H
