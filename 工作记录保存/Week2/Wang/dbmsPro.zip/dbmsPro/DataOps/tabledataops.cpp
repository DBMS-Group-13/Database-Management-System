#include "tabledataops.h"

TableDataOps::TableDataOps()
{

}

bool TableDataOps::Create(const QString strFilePath, TableEntity &te)
{
    return false;
}

bool TableDataOps::AddField(const QString strFilePath, FieldEntity &fe)
{
    return false;
}

int TableDataOps::GetTables(const QString strFilepath, TABLEARR &arr )
{
    return false;
}

bool TableDataOps::GetFields(const QString strFilepath, TableEntity &te)
{
    return false;
}

bool TableDataOps::AlterTable(const QString strFilePath, TableEntity &te)
{
    return false;
}
