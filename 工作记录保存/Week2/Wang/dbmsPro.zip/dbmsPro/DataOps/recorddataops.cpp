#include "recorddataops.h"

RecordDataOps::RecordDataOps()
{

}
bool RecordDataOps::Insert(TableEntity &te, RecordEntity &re)
{
    return false;
}

int RecordDataOps::SelectAll(TableEntity &te, RECORDARR &data)
{
    return 0;
}

bool RecordDataOps::Write(QFile &file, TableEntity &te, RecordEntity &re)
{
    return false;
}

bool RecordDataOps::Read(QFile &file, TableEntity &te, RecordEntity &re)
{
    return false;
}
