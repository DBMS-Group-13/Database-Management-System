#ifndef REF_H
#define REF_H

#include<QString>
#include<QFile>
#include<Windows.h>
#include<QHash>
#include<QDataStream>
#include<tchar.h>
#include "./Util/appexception.h"

#endif // REF_H
