#include "recordlogic.h"

RecordLogic::RecordLogic()
{

}
