#ifndef TABLELOGIC_H
#define TABLELOGIC_H


class TableLogic
{
public:
    TableLogic();
};

#endif // TABLELOGIC_H