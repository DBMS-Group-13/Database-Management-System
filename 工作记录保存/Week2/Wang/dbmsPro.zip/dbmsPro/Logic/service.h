#ifndef SERVICE_H
#define SERVICE_H


class service
{
public:
    service();
};

#endif // SERVICE_H