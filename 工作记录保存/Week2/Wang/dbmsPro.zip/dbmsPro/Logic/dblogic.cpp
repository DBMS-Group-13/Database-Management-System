#include "dblogic.h"

DBLogic::DBLogic()
{

}

/**************************************************
[FunctionName]	CreateDatabase
[Function]	Create database
[Argument]	CDBEntity &db: Database entity object, contains the name of the database.
[ReturnedValue]	bool: True if the operation is successful, other false.
**************************************************/
bool DBLogic::CreateDatabase(DBEntity &db)
{
    try
    {
        // Decide whether the file exists, if there is no,a file will be created.
        QString strDBFile = fileLogic.GetDBFile();
        if (QFileHelper::IsValidFile(strDBFile) == false)
        {
            if(QFileHelper::CreateFile(strDBFile) == false)
            {
                return false;
            }
        }

        // Read file, decide whether exists the database of the same name
        if (DB_Ops.GetDatabase(strDBFile, db) == true)
        {
            return false;
        }

        // Create database
        QString strDBFolder = fileLogic.GetDBFolder(db.GetName());
        db.SetFilepath(strDBFolder);
        if(DB_Ops.Create(strDBFile, db) == false)
        {
            return false;
        }
    }
    catch (AppException* e)
    {
        throw e;
    }
    catch (...)
    {
        //throw new AppException(_T("Failed to create database!"));
    }

    return true;
}

/**************************************************
[FunctionName]	GetDatabase
[Function]	Query the database information
[Argument]	CDBEntity &db: Database entity object, contains the name of the database.
        Queried database information will be saved to the object.
[ReturnedValue]	bool: True if exists the database of the same name, otherwise false
**************************************************/
bool DBLogic::GetDatabase(DBEntity &db)
{
    try
    {
        return DB_Ops.GetDatabase(fileLogic.GetDBFile(), db);
    }
    catch (AppException* e)
    {
        throw e;
    }
    catch (...)
    {
        //throw new AppException(_T("Failed to create database!"));
    }
    return false;
}
