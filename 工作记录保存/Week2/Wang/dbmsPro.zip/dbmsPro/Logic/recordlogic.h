#ifndef RECORDLOGIC_H
#define RECORDLOGIC_H


class RecordLogic
{
public:
    RecordLogic();
};

#endif // RECORDLOGIC_H