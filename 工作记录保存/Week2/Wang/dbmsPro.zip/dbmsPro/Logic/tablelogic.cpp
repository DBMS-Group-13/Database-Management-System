#include "tablelogic.h"

TableLogic::TableLogic()
{

}
